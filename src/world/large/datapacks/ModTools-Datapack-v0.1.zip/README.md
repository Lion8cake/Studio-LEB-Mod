# LEB-ModTools
Custom map creation & installation tool for LEB

Work in Progress Custom map creation & installation tool for LEB

When using the datapack, please use 1.18.2, not 1.19, it may be a while until LEB takes 1.19 worlds

### Credits

LEB ModTools project - [Emmie](https://github.com/DBTDerpbox)

Helping me with cleaning up code - [Symmetry System](https://github.com/OsricSystem)

Helping out with JSON parsing for grabbing the map ID - [Leah](https://github.com/Just-Leah)

Helping with accounting for loading maps with disabled map types - [Kyrptonaught](https://github.com/kyrptonaught)
